import React, { useState, useEffect } from "react";
// import AddTask from "./AddTask";

export default function Tasks(props) {
    return (
        <React.Fragment>
            <div>tasks section</div>
            {/*<AddTask />*/}
        </React.Fragment>
    )

};